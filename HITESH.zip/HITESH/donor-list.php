<?php
include("includes/header.php");
?>

<!-- banner 2 -->
<div class="inner-banner-w3ls">
    <div class="container">

    </div>
    <!-- //banner 2 -->
</div>
<!-- page details -->
<div class="breadcrumb-agile">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Blood Donar List</li>
        </ol>
    </div>
</div>
<!-- //page details -->

<!-- contact -->
<div class="agileits-contact py-5">
    <div class="py-xl-5 py-lg-3">

        <div class="w3ls-titles text-center mb-5">
            <h3 class="title">Blood Donor List</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
            <!-- <p class="mt-2">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
        </div>
        <!-- blog -->
        <div class="blog-w3ls py-5" id="blog">
            <div class="container py-xl-5 py-lg-3">
                <!-- <div class="w3ls-titles text-center mb-5">
                    <h3 class="title text-white">Some of the Donar</h3>
                    <span>
                        <i class="fas fa-user-md text-white"></i>
                    </span>
                </div> -->
                <div class="row package-grids mt-5">

                    <?php
                    $sql = "SELECT * from blooddonars";
                    $query = $conn->query($sql);

                    while ($data = $query->fetch_assoc()) {
                        if ($data['status'] == 'on') {
                            echo "
                    <div class='col-md-4 pricing' style='margin-top:2%;'>

                        <div class='price-top'>

                            <img src='images/blood-donor.jpg' alt='' class='img-fluid' />

                            <h3>$data[name]
                            </h3>
                        </div>
                        <div class='price-bottom p-4'>
                            <h4 class='text-dark mb-3'>Name: $data[name] </h4>
                            
                            <h4 class='text-dark mb-3'>Gender: $data[gender] </h4>
                            <h4 class='text-dark mb-3'>Blood Group: $data[bloodgroup] </h4>
                            <h4 class='text-dark mb-3'>Contact: $data[contact] </h4>

                            <a class='btn btn-primary' style='color:#fff'
                                href='bloodrequest.php?id=$data[id]'>Request</a>
                        </div>
                    </div>";
                        }
                    } ?>


                </div>
            </div>
        </div>
        <!-- //blog -->


    </div>

</div>
<!-- //contact -->





<?php
include("includes/footer.php");
?>