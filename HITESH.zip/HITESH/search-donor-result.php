<?php
include("includes/header.php");
$bloodgroup = '';
?>

<?php
if (isset($_POST["submit"])) {
    $bloodgroup = $conn->real_escape_string($_POST['bloodgroup']);
    $sql = "SELECT * from blooddonars WHERE bloodgroup='$bloodgroup'";
    $query = $conn->query($sql);
    // $data = $query->fetch_assoc();
}
?>

<div class="agileits-contact py-5" style="background-color: brown;">
    <div class="py-xl-5 py-lg-3">

        <div class="w3ls-titles text-center mb-5">
            <h3 class="title text-light">Search Result</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
            <!-- <p class="mt-2">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
        </div>
        <!-- blog -->
        <!-- <div class="blog-w3ls py-5" id="blog" style="background"> -->
        <div class="container py-xl-5 py-lg-3">
            <!-- <div class="w3ls-titles text-center mb-5">
                    <h3 class="title text-white">Some of the Donar</h3>
                    <span>
                        <i class="fas fa-user-md text-white"></i>
                    </span>
                </div> -->
            <div class="row package-grids mt-5">

                <?php
                if ($query->num_rows > 0) {
                    while ($data = $query->fetch_assoc()) {
                        if ($data['status'] == 'on') {
                            echo "
                    <div class='col-md-4 pricing' style='margin-top:2%;'>

                        <div class='price-top'>

                            <img src='images/blood-donor.jpg' alt='' class='img-fluid' />

                            <h3>$data[name]
                            </h3>
                        </div>
                        <div class='price-bottom p-4'>
                            <h4 class='text-dark mb-3'>Name: $data[name] </h4>
                            
                            <h4 class='text-dark mb-3'>Gender: $data[gender] </h4>
                            <h4 class='text-dark mb-3'>Blood Group: $data[bloodgroup] </h4>
                            <h4 class='text-dark mb-3'>Contact: $data[contact] </h4>

                            <a class='btn btn-primary' style='color:#fff'
                                href='bloodrequest.php?id=$data[id]'>Request</a>
                        </div>
                    </div>";
                        }
                        else {
                            echo "<p style='color: red; margin-left: 30%; text-align: center; font-size: 60px; background-color:white'>No Result Found</p>";
        
                        } 
                    }
                    
                } else {
                    echo "<p style='color: red; margin-left: 30%; text-align: center; font-size: 60px; background-color:white'>No Result Found</p>";

                } ?>


            </div>
        </div>
        <!-- </div> -->
        <!-- //blog -->


    </div>

</div>

<?php
include("includes/footer.php");
?>