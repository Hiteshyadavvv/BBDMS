<?php
include("../includes/dbconnection.php");
?>
<?php
if (isset($_POST["submit"])) {

    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $bloodgroup = $_POST['bloodgroup'];
    $address = $_POST['address'];
    $message = $_POST['message'];
    $date = $_POST['date'];
    $status = $_POST['status'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);


    $query = "INSERT INTO blooddonars(name,contact,email,gender,age,bloodgroup,address,message,date,status,password) VALUES ('$name','$contact','$email','$gender','$age','$bloodgroup','$address','$message','$date','$status','$password')";
    $result = $conn->query($query);
    header("Location:./login.php");
    exit;
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./registerdonor.css">
</head>

<body>
    <!-- Background image container -->
    <div class="background">
        <div class="container login-container">
            <div class="col-md-6 login-form mt-3 mb-3">
                <h2 class="text-center mb-4">Register Form </h2>
                <form action="" method="POST">
                    <!-- name input field with label -->
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" placeholder="Enter your Name" required>
                    </div>
                    <!-- number input field with label -->
                    <div class="form-group">
                        <label for="phone">Mobile Number</label>
                            <input type="tel" class="form-control" name="contact" placeholder="Enter your Phone Number" required
                               pattern="\d{10,12}" maxlength="12" minlength="10">                    
                                </div>                  
                    <!-- email input field with label -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" placeholder="Enter your Email" required>
                    </div>
                    <!-- age input field with label -->
                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" class="form-control" name="age" placeholder="Enter your Age" required>
                    </div>
                    <!-- gender input field with label -->
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select name="gender" class="form-control" id="">
                            <option value="" selected disable>select</option>
                            <option value="male">male</option>
                            <option value="female">female</option>
                        </select>
                        <!-- <input type="text" class="form-control" name="gender" placeholder="Enter your Gender" required> -->
                    </div>
                    <!-- bloodgroup input field with label -->
                    <div class="form-group">
                        <label for="bloodgroup">Blood Group</label>
                        <!-- <input type="text" class="form-control" name="bloodgroup" placeholder="Enter your Blood Group"
                            required> -->
                        <select name="bloodgroup" class="form-control" id="">
                            <option value="" selected disable>select</option>
                            <option value="O-">O-</option>
                            <option value="O+">O+</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                    <!-- address input field with label -->
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="address" placeholder="Enter your Address"
                            required>
                    </div>
                    <!-- bloodgroup input field with label -->
                    <div class="form-group">
                        <label for="message">Message</label>
                        <input type="text" class="form-control" name="message" placeholder="Enter Messages" required>
                    </div>
                    <!-- Date input field with label -->
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" class="form-control" id="date" name="date" placeholder="Enter Date" required>
                    </div>
                    <!-- Status input field with label -->
                    <!-- <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="" class="form-control">
                            <option value="" selected disabled>Select Status</option>
                            <option value="on">on</option>
                            <option value="off">off</option>
                        </select>
                    </div> -->
                    <!-- Password input field with label -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Enter your password" required>
                    </div>

                    <!-- Register button -->
                    <button type="submit" name="submit" class="btn btn-primary btn-block">Register</button>
                </form>

                <!-- Links for Forgot Password and Back to Home -->
                <div class="links-container mt-3 text-center">
                    Already Register? &nbsp &nbsp<a href="login.php">Sign in</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional, only needed if you want to use Bootstrap's JS components) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>