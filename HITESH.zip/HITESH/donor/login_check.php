<?php
$server="localhost";
$username="root";
$password= "";
$database= "bbdmsdb";
$conn=mysqli_connect($server,$username,$password,$database);
?>

<?php

$email=$_POST['email'];
$password=$_POST['password'];
$getuser="SELECT * FROM blooddonars WHERE email='$email'";
$result=$conn->query("$getuser");
$data=$result->fetch_assoc();

if($data['email']){
    if(password_verify($password, $data['password'])){
        session_start();
        $_SESSION['email']=$email;
        // header('location:../backend/donor/dashboard.php');

    }
    else{
        echo "<h1>Password doesnt match</h1>";
    }
}
else{
    echo "<h1>you are not resister with $email</h1>";
}

?>
