<?php
include("includes/header.php");
?>




<!-- banner 2 -->
<div class="inner-banner-w3ls">
    <div class="container">

    </div>
    <!-- //banner 2 -->
</div>
<!-- page details -->
<div class="breadcrumb-agile">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Search Blood Donar List</li>
        </ol>
    </div>
</div>
<!-- //page details -->
<div class="agileits-contact py-5">
    <div class="py-xl-5 py-lg-3">

        <div class="w3ls-titles text-center mb-5">
            <h3 class="title"> Search Blood Donor List</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>

        </div>
        <div class="container">
            <div class="card">
                <div class="card-header">
                    <label for=""><i>Blood Group*</i></label>
                </div>
                <form action="search-donor-result.php" method="post">
                    <div class="card-body">

                        <select name="bloodgroup" class="form-control w-25" id="">
                            <option value="" selected disable>select</option>
                            <option value="O-">O-</option>
                            <option value="O+">O+</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                    <div class="card-footer">

                        <button type='submit' class="btn btn-primary" name="submit">Search</button>

                    </div>
                </form>
                <!--<label for=""><i>Blod Group*</i></label>-->



            </div>


            <?php
            include("includes/footer.php");
            ?>