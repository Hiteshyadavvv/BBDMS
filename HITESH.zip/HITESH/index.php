<?php
include("includes/header.php");
?>


<!-- banner -->
<div class="slider">
    <div class="callbacks_container">
        <ul class="rslides callbacks callbacks1" id="slider4">
            <li>
                <div class="banner-top1">
                    <div class="banner-info_agile_w3ls">
                        <div class="container">
                            <h3>Blood bank services that you
                                <span>can trust</span>
                            </h3>

                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="banner-top2">
                    <div class="banner-info_agile_w3ls">
                        <div class="container">
                            <h3>One Blood Donation Save One Lives
                                <span>every day</span>
                            </h3>

                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="banner-top3">
                    <div class="banner-info_agile_w3ls">
                        <div class="container">
                            <h3><span>"Sometimes money cannot save life but donated blood can</span>
                            </h3>

                        </div>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
<!-- //banner -->


<!-- banner bottom -->
<div class="banner-bottom py-5">
    <div class="d-flex container py-xl-3 py-lg-3">
        <div class="banner-left-bottom-w3ls offset-lg-2 offset-md-1">
            <!-- <h3 class="text-white my-3">High professional doctors</h3> -->
            <h3>"To give blood, you need neither extra strength nor extra food, an extra income, nor an extra hour. All you need is a big heart."</p>
        </div>
        <div class="button">
            <a href="about-us.php" class="w3ls-button-agile">Read More
                <i class="fas fa-hand-point-right"></i>
            </a>
        </div>
    </div>
</div>
<!--// banner bottom-->
<!-- blog -->
<div class="blog-w3ls py-5" id="blog">
    <div class="container py-xl-5 py-lg-3">
        <div class="w3ls-titles text-center mb-5">
            <h3 class="title text-white">Some of the Donar</h3>
            <span>
                <i class="fas fa-user-md text-white"></i>
            </span>
        </div>
        <div class="row package-grids mt-5">

            <?php
            $sql = "SELECT * from blooddonars";
            $query = $conn->query($sql);

            while ($data = $query->fetch_assoc()) {
                if ($data['status'] == 'on') {
                    echo "
                    <div class='col-md-4 pricing' style='margin-top:2%;'>

                        <div class='price-top'>

                            <img src='images/blood-donor.jpg' alt='' class='img-fluid' />

                            <h3>$data[name]
                            </h3>
                        </div>
                        <div class='price-bottom p-4'>
                            <h4 class='text-dark mb-3'>Gender: $data[gender] </h4>
                            <p class='card-text'><b>Blood Group :</b> $data[bloodgroup] </p>

                            <a class='btn btn-primary' style='color:#fff'
                                href='bloodrequest.php?id=$data[id]'>Request</a>
                        </div>
                    </div>";
                }
            } ?>


        </div>
    </div>
</div>
<!-- //blog -->

<!-- treatments -->
<div class="screen-w3ls py-5">
    <div class="container py-xl-5 py-lg-3">
        <div class="w3ls-titles text-center mb-5">
            <h3 class="title">BLOOD GROUPS</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
            <p class="mt-2">blood group of any human being will mainly fall in any one of the following groups..</p>
        </div>
        <div class="row">
            <div class="col-lg-6">

                <ul>
                    <li>A positive or A negative</li>
                    <li>B positive or B negative</li>
                    <li>O positive or O negative</li>
                    <li>AB positive or AB negative.</li>
                </ul>
                <p>A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out
                    the following recommended foods to eat prior to your donation.</p>
            </div>
            <div class="col-lg-6">
                <img class="img-fluid rounded" src="images/blood-donor (1).jpg" alt="">
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-8">
                <h4 style="padding-top: 30px;">UNIVERSAL DONORS AND RECIPIENTS</h4>
                <p>
                    The most common blood type is O, followed by type A.

                    Type O individuals are often called "universal donors" since their blood can be transfused into
                    persons with any blood type. Those with type AB blood are called "universal recipients" because they
                    can receive blood of any type.</p>
            </div>
            <div class="col-md-4" style="padding-top: 30px;">

                <a href="donor/login.php">
                    <button class="btn btn-lg btn-dark btn-block login-button ml-lg-5 mt-lg-0 mt-4 mb-lg-0 mb-3">Become
                        a donor</button>
                </a>
            </div>
        </div>
    </div>
</div>
<!-- //treatments -->

<?php
include("includes/footer.php");
?>