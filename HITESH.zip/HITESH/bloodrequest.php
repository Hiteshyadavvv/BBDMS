<?php
include("includes/header.php");
?>


<?php

if (isset($_POST['send'])) {
    $id = $_GET['id']; // Fetching donor ID from URL

    $query = "SELECT * FROM blooddonars WHERE id='$id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();

        $donarname = $data['name'];
        $donarcontact = $data['contact'];
        $bloodgroup = $data['bloodgroup'];

        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $bloodfor = $_POST['bloodfor'];
        $message = $_POST['message'];

        $sql = "INSERT INTO bloodrequest (donarname, donarcontact, bloodgroup, name, contact, email, bloodfor, message) 
                VALUES ('$donarname', '$donarcontact', '$bloodgroup', '$name', '$contact', '$email', '$bloodfor', '$message')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Request submitted successfully!'); window.location.href='bloodrequest.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Error: Donor with ID $id not found!');</script>";
    }
}
?>



<!-- banner 2 -->
<div class="inner-banner-w3ls">
    <div class="container">

    </div>
    <!-- //banner 2 -->
</div>
<!-- page details -->
<div class="breadcrumb-agile">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Blood Needed Person</li>
        </ol>
    </div>
</div>
<!-- //page details -->

<!-- contact -->
<div class="agileits-contact py-5">
    <div class="py-xl-5 py-lg-3">
        <div class="w3ls-titles text-center mb-5">
            <h3 class="title">Contact For Blood</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
            <!-- <p class="mt-2">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
        </div>
        <div class="d-flex">
            <div class="col-lg-5 w3_agileits-contact-left">
            </div>
            <div class="col-lg-7 contact-right-w3l">
                <h5 class="title-w3 text-center mb-5">Fill following form for blood</h5>
                <form action=" " method="post">
                    <div class="d-flex space-d-flex">
                        <div class="form-group grid-inputs">
                            <input type="text" class="form-control" id="name" name="name" required
                                placeholder="Please enter your name.">
                        </div>
                        <div class="form-group grid-inputs">
                            <input type="text" class="form-control" id="contact" name="contact" required
                                placeholder="Please enter your phone number" pattern="\d{10,12}"
                                title="Phone number must be between 10 and 12 digits" maxlength="12">
                        </div>

                    </div>
                    <div class="d-flex space-d-flex">
                        <div class="form-group grid-inputs">
                            <input type="email" class="form-control" id="email" name="email" required
                                placeholder="Please enter your email address.">
                        </div>
                        <div class="form-group grid-inputs">
                            <select name="bloodfor" class="form-control" required>
                                <option value="" selected disabled>Blood Require For</option>
                                <option value="father">Father</option>
                                <option value="mother">Mother</option>
                                <option value="brother">Brother</option>
                                <option value="sister">Sister</option>
                                <option value="others">Others</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea rows="10" cols="100" class="form-control" id="message" name="message"
                            placeholder="Please enter your message" maxlength="999" style="resize:none"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Send Message" name="send">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php
include("includes/footer.php");
?>