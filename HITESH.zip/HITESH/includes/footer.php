<?php
include('dbconnection.php');

?>
<footer style="background-color:rgba(12, 82, 212, 0.8);">
	<div class="w3ls-footer-grids pt-sm-4 pt-3">
		<div class="container py-xl-5 py-lg-3">
			<div class="row">
				<div class="col-md-4 w3l-footer">
					<h2 class="mb-sm-3 mb-2">
						<a href="index.php" class="text-white font-italic font-weight-bold">
							<span>Blood Bank & </span>Donor Management System
							<i class="fas fa-syringe ml-2"></i>
						</a>
					</h2>
					<p>Our mission is to improve the blood donation process using
						the latest technology and caring service.
						By making the system more open, reliable, and easy to use,
						we aim to save many lives
						and help create a healthier world for everyone.</p>
				</div>
				<div class="col-md-4 w3l-footer my-md-0 my-4">
					<h3 class="mb-sm-3 mb-2 text-white">Address</h3>
					<ul class="list-unstyled">
						<?php
						$sql = "SELECT * from page WHERE type='contactus'";
						$query = $conn->query($sql);
						$data = $query->fetch_assoc();
						?>
						<li>
							<i class="fas fa-location-arrow float-left"></i>
							<p class="ml-4">
								<span><?php echo $data['description']; ?>
							</p>
							<div class="clearfix"></div>
						</li>
						<li class="my-3">
							<i class="fas fa-phone float-left"></i>
							<p class="ml-4"><?php echo "(+91) ";?><?php echo $data['contact']; ?></p>
							<div class="clearfix"></div>
						</li>
						<li>
							<i class="far fa-envelope-open float-left"></i>
							<a href="mailto:info@example.com" class="ml-3"><?php echo $data['email']; ?></a>
							<div class="clearfix"></div>
						</li>

					</ul>
				</div>
				<div class="col-md-4 w3l-footer">
					<h3 class="mb-sm-3 mb-2 text-white">Quick Links</h3>
					<div class="nav-w3-l">
						<ul class="list-unstyled">
							<li>
								<a href="index.php">Home</a>
							</li>
							<li class="mt-2">
								<a href="about-us.php">About Us</a>
							</li>
							<li class="mt-2">
								<a href="contact-us.php">Contact Us</a>
							</li>

						</ul>
					</div>
				</div>
			</div>
			<div class="border-top mt-5 pt-lg-4 pt-3 pb-lg-0 pb-3 text-center">
				<p class="copy-right-grids mt-lg-1">© Blood Bank Donor Management System

				</p>
			</div>
		</div>
	</div>
</footer>
<!-- //footer -->
</body>

<script src="public/frontend/js/jquery-2.2.3.min.js"></script>
<!-- Default-JavaScript-File -->

<!-- banner slider -->
<script src="public/frontend/js/responsiveslides.min.js"></script>
<script>
	$(function () {
		$("#slider4").responsiveSlides({
			auto: true,
			pager: true,
			nav: true,
			speed: 1000,
			namespace: "callbacks",
			before: function () {
				$('.events').append("<li>before event fired.</li>");
			},
			after: function () {
				$('.events').append("<li>after event fired.</li>");
			}
		});
	});
</script>
<!-- //banner slider -->

<!-- fixed navigation -->
<script src="public/frontend/js/fixed-nav.js"></script>
<!-- //fixed navigation -->

<!-- smooth scrolling -->
<script src="public/frontend/js/SmoothScroll.min.js"></script>
<!-- move-top -->
<script src="public/frontend/js/move-top.js"></script>
<!-- easing -->
<script src="public/frontend/js/easing.js"></script>
<!--  necessary snippets for few javascript files -->
<script src="public/frontend/js/medic.js"></script>

<script src="public/frontend/js/bootstrap.js"></script>
<!-- Necessary-JavaScript-File-For-Bootstrap -->

<!-- //Js files -->


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</html>