<?php
include("includes/header.php");
?>

<?php
$sql = "SELECT * from page WHERE type='aboutus'";
$query = $conn->query($sql);
$data = $query->fetch_assoc();
?>

<!-- banner 2 -->
<div class="inner-banner-w3ls">
    <div class="container">

    </div>
    <!-- //banner 2 -->
</div>
<!-- page details -->
<div class="breadcrumb-agile">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
        </ol>
    </div>
</div>
<!-- //page details -->

<!-- about -->
<section class="about py-5">
    <div class="container py-xl-5 py-lg-3">

        <div class="w3ls-titles text-center mb-md-5 mb-4">
            <h3 class="title">About-us<?php
            //   echo htmlentities($result->PageName); 
            ?></h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
        </div>
        <p class="aboutpara text-center mx-auto"><?php
        //   echo $result->detail; 
        ?></p>
        <div>
            <?php
                echo "$data[description]";
            ?>
            <!-- <p>
                Welcome to the Blood Bank Donor Management System!
                Our project is designed to make the blood donation process easier and more efficient.
                It connects donors, blood recipients, and hospitals, ensuring that life-saving blood is always available
                when needed.
                The system allows donors to sign up, schedule their donations, and track their donation history.
                It also helps blood banks keep track of their blood supply and manage donor details effectively.
                Our main goal is to make donating blood simple, organized, and transparent, helping save lives and
                improve healthcare.
                We focus on security, ease of use, and accuracy to ensure the system is helpful for both donors and
                medical facilities.
                Our aim is to create a world where everyone can get the blood they need in an emergency, with the
                support of a strong and caring community.
            </p> -->
        </div>
    </div>
</section>
<!-- //about -->




<?php
include("includes/footer.php");
?>