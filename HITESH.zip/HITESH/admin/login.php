<?php
$server="localhost";
$username="root";
$password= "";
$database= "bbdmsdb";
$conn=mysqli_connect($server,$username,$password,$database);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./adminlogin1.css">
</head>

<body>
    <?php
  $error = '';
  ?>
    <!-- Background image container -->
    <div class="background">
        <div class="container login-container">
            <div class="col-md-4 login-form">
                <h2 class="text-center mb-4">BloodBank & Donor Management System </h2>
                <?php
    if (isset($_POST["submit"])) {
      $username = $_POST['username'];
      $password = $_POST['password'];
      $getuser = "SELECT * FROM admin WHERE username='$username'";
      $result = $conn->query($getuser);  // Removed unnecessary quotes
      $data = $result->fetch_assoc();

      if ($data && $data['username'] != null) {  // Fixed condition
        if (password_verify($password, $data['password'])) {  // Removed incorrect assignment
          session_start();
          $_SESSION['username'] = $data['username'];

          header('location:../backend/admin/dashboard.php');
          exit();
        } else {
          $error = "<h6 style='color:red;text-align: center;'>Password doesn't match</h6>"; // Fixed variable name
        }
      } else {
        $error = "<h6 style='color:red;text-align: center;'>You are not registered with username: $username</h6>";
      }
    }
    ?>
                <form action=" " method="POST">
                <h2 style="text-align: center;">Login</h2>
                    <?php
      echo $error;
      ?>
                    <!-- Username input field with label -->
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" id="username" name="username"
                            placeholder="Enter your username" required>
                    </div>

                    <!-- Password input field with label -->
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password"
                            placeholder="Enter your password" required>
                    </div>

                    <!-- Login button -->
                    <button type="submit" name="submit" class="btn btn-primary btn-block">Login</button>
                </form>

                <!-- Links for Forgot Password and Back to Home -->
                <div class="links-container mt-3 ">
                    <a href="forgot-password.php">Forgot Password?</a>
                </div>
                <div class="mt-3 home">
                    <a href="../index.php"><button type="submit" class="btn btn-success btn-block"><b>Back to
                                Home!!</b></button></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional, only needed if you want to use Bootstrap's JS components) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>