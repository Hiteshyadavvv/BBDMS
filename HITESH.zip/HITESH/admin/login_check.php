<?php
$server="localhost";
$username="root";
$password= "";
$database= "bbdmsdb";
$conn=mysqli_connect($server,$username,$password,$database);
?>

<?php

$username=$_POST['username'];
$password=$_POST['password'];
$getuser="SELECT * FROM admin WHERE username='$username'";
$result=$conn->query("$getuser");
$data=$result->fetch_assoc();

if($data['username']){
    if(password_verify($password, $data['password'])){
        session_start();
        $_SESSION['username']=$username;
        header('location:../backend/admin/dashboard.php');

    }
    else{
        echo "<h1>Password doesnt match</h1>";
    }
}
else{
    echo "<h1>you are not resister with $username</h1>";
}

?>
