<?php
include("../includes/dbconnection.php");


$query_admin = "SELECT * FROM admin";
$result_admin = $conn->query($query_admin);
$data_admin = $result_admin->fetch_assoc();

$error = ""; // Initialize error message variable

if (isset($_POST["submit"])) {
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $newpassword = $_POST['newpassword'];
    $confirmpassword = $_POST['confirmpassword'];

    // if ($data_admin['Email'] != $email)
    // {
    //     $error = "<h4 style='color:red;'>Admin account not found in this $email</h4>";
    // }
    // if ($data_admin['MobileNumber'] != $phone)
    // {
    //     $error = "<h4 style='color:red;'>Admin account not found in this  $phone</h4>";
    // }

    if ($data_admin['email'] == $email && $data_admin['phone'] == $phone) {   // Check if data exists
        if ($newpassword === $confirmpassword) {
            // Passwords match
            $changepassword = password_hash($_POST['newpassword'], PASSWORD_BCRYPT);
            $query = "UPDATE admin set password='$changepassword'";
            $result = $conn->query($query);

            $error = "<h5 style='color:green;text-align: center;'>Password successfully Changed</h5>";
        } else {
            $error = "<h5 style='color:red;text-align: center;'>Passwords do not match</h5>";
        }

    } else {
        $error = "<h5 style='color:red;text-align: center;'>Admin account not found</h5>";
    }
}


?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./adminlogin1.css">
</head>

<body>
    <!-- Background image container -->
    <div class="background">
        <div class="container login-container">
            <div class="col-md-4 login-form">
                <form action=" " method="POST">
                    <h2 style="text-align: center;">Reset Password</h2>
                    <?php
      echo $error;
      ?>
                    <!-- Email input field with label -->
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" class="form-control" id="" name="email"
                            placeholder="Enter your Email" required>
                    </div>
                    <!-- Mobile Number input field with label -->
                    <div class="form-group">
                        <label for="">Mobile Number</label>
                        <input type="number" class="form-control" id="" name="phone"
                            placeholder="Enter your Mobile Number" required>
                    </div>

                    <!-- Password input field with label -->
                    <div class="form-group">
                        <label for="">New Password</label>
                        <input type="password" class="form-control" id="" name="newpassword"
                            placeholder="Enter your New Password" required>
                    </div>

                    <div class="form-group">
                        <label for="">Confirm Password</label>
                        <input type="password" class="form-control" id="" name="confirmpassword"
                            placeholder="Enter your Confirm Password" required>
                    </div>
                    
                    <!-- Login button -->
                    <button type="submit" name="submit" class="btn btn-primary btn-block">Reset</button>
                </form>

                <div class="mt-3 home">
                    <a href="./login.php"><button type="submit" class="btn btn-success btn-block"><b>Back to
                               Login!!</b></button></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS (optional, only needed if you want to use Bootstrap's JS components) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>

</html>