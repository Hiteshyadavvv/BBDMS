<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Manag Blood Group</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/donarheader.php');
    ?>

    <div class="ts-main-content">
        <?php include('../includes/donarsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title mt-4">Manage Total Request</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Manage Total Request</div>
                            <div class="panel-body">
                                <table class="display table table-striped table-bordered table-hover" cellspacing="0"
                                    width="100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name of Donar</th>
                                            <th>Conatact Number of Donar</th>
                                            <th>Blood Group</th>
                                            <th>Name of Requirer</th>
                                            <th>Mobile Number of Requirer</th>
                                            <th>Email of Requirer </th>
                                            <th>Blood Require For</th>
                                            <th>Message of Requirer</th>
                                            <th>Apply Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <!-- <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name of Donar</th>
                                            <th>Conatact Number of Donar</th>
                                            <th>Blood Group</th>
                                            <th>Name of Requirer</th>
                                            <th>Mobile Number of Requirer</th>
                                            <th>Email of Requirer </th>
                                            <th>Blood Require For</th>
                                            <th>Message of Requirer</th>
                                            <th>Apply Date</th>
                                        </tr>
                                        </tr>
                                    </tfoot> -->
                                    <tbody>
                                        <?php

                                        $email = $_SESSION['email'];
                                        $query_donar = "SELECT * FROM blooddonars WHERE email='$email'";
                                        $result_donar = $conn->query($query_donar);
                                        $data_donar = $result_donar->fetch_assoc();

                                        $name=$data_donar['name'];

                                        $query = "SELECT * FROM bloodrequest WHERE donarname='$name'";
                                        $result = $conn->query($query);
                                        while ($data = $result->fetch_assoc()) {

                                            echo "
                            <tr>
                              <td>
                                $data[id]         
                              </td>
                              <td>
                                $data[donarname]           
                              </td>
                              <td>
                                $data[donarcontact]            
                              </td>
                              <td>
                                $data[bloodgroup]         
                              </td>
                              <td>
                                $data[name]           
                              </td>
                              <td>
                                $data[contact]            
                              </td>
                              <td>
                                $data[email]         
                              </td>
                              <td>
                                $data[bloodfor]           
                              </td>
                              <td>
                                $data[message]      
                              </td>
                              <td>
                                $data[applydate]           
                              </td>
                               <td>
                                $data[applydate]           
                              </td>
                                     
                            </tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Loading Scripts -->
    <?php include('../includes/js.php'); ?>

</body>

</html>

