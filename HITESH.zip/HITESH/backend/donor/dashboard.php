<?php
session_start();
if (isset($_SESSION['email'])) {

} else {
  header('location:../../donor/login.php');
  exit;

}
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="theme-color" content="#3e454c">

  <title>BBDMS | Donor Dashboard</title>
  <?php include('../includes/cs.php'); ?>
</head>


<body>
  <?php include('../includes/donarheader.php'); ?>

  <div class="ts-main-content">
    <?php include('../includes/donarsidebar.php'); ?>
    <div class="content-wrapper">
      <div class="container-fluid">

        <div class="row">
          <div class="col-md-12">

            <h2 class="page-title mt-2">Dashboard</h2>

            <div class="row">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-4">
                    <div class="panel panel-default">
                      <div class="panel-body bk-info text-light">
                        <div class="stat-panel text-center">
                          <?php
                          $email = $_SESSION['email'];
                          $query_donar = "SELECT * FROM blooddonars WHERE email='$email'";
                          $result_donar = $conn->query($query_donar);
                          $data_donar = $result_donar->fetch_assoc();

                          $name = $data_donar['name']; // safest and clean
                          
                          $totalrequest = "SELECT COUNT(*) AS totalrequest FROM bloodrequest WHERE donarname='$name'";
                          $total_result = $conn->query($totalrequest);
                          $total_row = $total_result->fetch_assoc();
                          ?>
                          <div class="stat-panel-number h1">
                            <?php
                            echo $total_row['totalrequest'];
                            ?>
                          </div>

                          <div class="stat-panel-title text-uppercase">Total Blood Request Received
                          </div>
                        </div>
                      </div>
                      <a href="manage-total-request.php" class="block-anchor panel-footer">Full
                        Detail <i class="fa fa-arrow-right"></i></a>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Loading Scripts -->
  <?php include('../includes/js.php'); ?>

</body>

</html>