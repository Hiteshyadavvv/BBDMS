<?php
session_start();
if (isset($_SESSION['email'])) {

} else {
    header('location:../../donor/login.php');
    exit;

}
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Donor Dashboard</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/donarheader.php');


    $email = $_SESSION['email'];
    $query_donar = "SELECT * FROM blooddonars WHERE email='$email'";
    $result_donar = $conn->query($query_donar);
    $data_donar = $result_donar->fetch_assoc();

    if (isset($_POST["submit"])) {

        $name = $_POST['name'];
        $contact = $_POST['contact'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $message = $_POST['message'];
        $status = $_POST['status'];

        $query = "UPDATE blooddonars set name='$name',contact='$contact',gender='$gender',age='$age',address='$address',message='$message',status='$status' WHERE email='$email' ";
        $result = $conn->query($query);
        if ($result) {
            echo "<script>
                alert('Your Profile has been Update successfully');
                window.location.href = './update-profile.php';
            </script>";
            exit();
        }
        
    }
    ?>
    <div class="ts-main-content">
        <?php include('../includes/donarsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12 mt-3">

                        <h2 class="page-title mt-2">Update Profile</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Update Profile</div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <form action="" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Name</label>
                                                    <input type="text" name="name" class="form-control"
                                                        value="<?php echo $data_donar['name']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Contact Number</label>
                                                    <input type="text" name="contact" id="contact" class="form-control"
                                                        value="<?php echo $data_donar['contact']; ?>"
                                                        pattern="\d{10,12}"
                                                        title="Phone number must be between 10 and 12 digits"
                                                        maxlength="12" minlength="10" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Email</label>
                                                    <input type="text" name="email" id="email" class="form-control"
                                                        value="<?php echo $data_donar['email']; ?>" required readonly>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Gender</label>
                                                    <input type="text" name="gender" id="gender" class="form-control"
                                                        value="<?php echo $data_donar['gender']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Age</label>
                                                    <input type="text" name="age" id="age" class="form-control"
                                                        value="<?php echo $data_donar['age']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Blood Group</label>
                                                    <input type="text" name="bloodgroup" id="bloodgroup"
                                                        class="form-control"
                                                        value="<?php echo $data_donar['bloodgroup']; ?>" required
                                                        readonly>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Address</label>
                                                    <input type="text" name="address" id="address" class="form-control"
                                                        value="<?php echo $data_donar['address']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Message</label>
                                                    <input type="message" name="message" id="message"
                                                        class="form-control"
                                                        value="<?php echo $data_donar['message']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Date Of Request</label>
                                                    <input type="date" name="date" id="date" class="form-control"
                                                        value="<?php echo $data_donar['date']; ?>" required readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <div class="form-group">
                                                <label for="">Status</label>
                                                    <select name="status" class="form-control">
                                                        <option value="" selected disabled>-Select-</option>
                                                        <option value="on" <?php if( $data_donar['status'] == 'on') echo 'selected'; ?>>On</option>
                                                        <option value="off" <?php if( $data_donar['status'] == 'off') echo 'selected'; ?>>Off</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <button type="submit" class="btn btn-primary w-25" name="submit">Update</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Loading Scripts -->
    <?php include('../includes/js.php'); ?>


</body>

</html>