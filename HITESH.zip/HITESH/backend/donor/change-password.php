<?php
session_start();
if (isset($_SESSION['email'])) {

} else {
    header('location:../../donor/login.php');
    exit;

}
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Change Password</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/donarheader.php');
    $email = $_SESSION['email'];

    ?>


    <div class="ts-main-content">
        <?php include('../includes/donarsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title mt-4">Update Password</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Change Password</div>
                            <div class="panel-body">

                                <?php
                                $query_donar = "SELECT * FROM blooddonars WHERE email='$email'";
                                $result_donar = $conn->query($query_donar);
                                $data_donar = $result_donar->fetch_assoc();

                                $error = ""; // Initialize error message variable
                                
                                if (isset($_POST["submit"])) {
                                    $currentpassword = $_POST['currentpassword'];
                                    $newpassword = $_POST['newpassword'];
                                    $confirmpassword = $_POST['confirmpassword'];

                                    if ($data_donar && isset($data_donar['password'])) { // Check if data exists
                                        if (password_verify($currentpassword, $data_donar['password'])) {
                                            if ($newpassword === $confirmpassword) {
                                                // Passwords match
                                                $changepassword = password_hash($_POST['newpassword'], PASSWORD_BCRYPT);
                                                $query = "UPDATE blooddonars set password='$changepassword' WHERE email='$email'";
                                                $result = $conn->query($query);

                                                $error = "<h6 style='color:green;'>Password successfully updated</h6>";
                                            } else {
                                                $error = "<h6 style='color:red;'>New passwords do not match</h6>";
                                            }
                                        } else {
                                            $error = "<h6 style='color:red;'>Wrong current password</h6>";
                                        }
                                    }
                                    // else {
                                    //     $error = "<h6 style='color:red;'>Donor account not found</h6>";
                                    // }
                                }
                                ?>

                                <!-- Display the error message -->
                                <?php echo $error; ?>


                                <form action=" " method="POST" enctype="multipart/form-data">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Current Password</label>
                                                    <input type="password" name="currentpassword" class="form-control"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">New Password</label>
                                                    <input type="password" name="newpassword" id="newpassword"
                                                        class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Confirm Password</label>
                                                    <input type="password" name="confirmpassword" cid="confirmpassword"
                                                        class="form-control" required>
                                                </div>
                                            </div>

                                        </div>
                                        <br>
                                        <button type="submit" class="btn btn-primary w-25" name="submit"
                                            onclick="checkpass();">Change
                                            Password</button>

                                    </div>
                                </form>

                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Loading Scripts -->
        <?php include('../includes/js.php'); ?>

</body>

</html>