<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Update Profile</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/adminheader.php'); ?>
    <?php


    if (isset($_POST["submit"])) {
        $bloodgroup = $_POST['bloodgroup'];
        $query = "INSERT INTO bloodgroup(bloodgroup) VALUES ('$bloodgroup')";
        $result = $conn->query($query);
        header("location:manage-bloodgroup.php");
        exit;


    }

    ?>

    <div class="ts-main-content">
        <?php include('../includes/adminsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title mt-2">Add Blood Group</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Add Blood Group</div>
                            <div class="panel-body">
                                <form method="post" name="" class="form-horizontal">

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Blood Group</label>
                                        <div class="col-sm-8">
                                        <input type="text" class="form-control" name="bloodgroup" id="bloodgroup"
                                        style="border: 1px solid black;" required placeholder="Enter Blood Group">
                                        </div>
                                    </div>
                                    <div class="hr-dashed"></div>

                                    <div class="form-group">
                                        <div class="col-sm-8 col-sm-offset-4">

                                            <button class="btn btn-primary" name="submit" type="submit">Submit</button>
                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Loading Scripts -->
        <?php include('../includes/js.php'); ?>

</body>

</html>