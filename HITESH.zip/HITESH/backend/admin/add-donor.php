<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Update Profile</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/adminheader.php'); ?>
    <?php
    $query = "SELECT * FROM blooddonars";
    $result = $conn->query($query);
    $data = $result->fetch_assoc();


if (isset($_POST["submit"])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $bloodgroup = $_POST['bloodgroup'];
    $address = $_POST['address'];
    $status = $_POST['status'];
    // $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $query = "INSERT INTO blooddonars (name,email,contact,gender,age,bloodgroup,address,status) VALUES('$name','$email','$contact','$gender','$age','$bloodgroup','$address','$status' )";
    $result = $conn->query($query);
    header("location:manage-donors-list.php");
    exit;
    

}

?>

    <div class="ts-main-content">
        <?php include('../includes/adminsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title mt-2">Add Donor</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Add Donor</div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <form action="" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Name</label>
                                                    <input type="text" name="name"  class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Email</label>
                                                    <input type="text" name="email"  class="form-control"  required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Contact Number</label>
                                                    <input type="text" name="contact" id="contact" class="form-control"  
                                                        pattern="\d{10,12}"
                                                        title="Phone number must be between 10 and 12 digits" maxlength="12"
                                                        minlength="10" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Gender</label>
                                                    <input type="text" name="gender"  class="form-control"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Age</label>
                                                    <input type="number" name="age"  class="form-control" 
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Blood Group</label>
                                                    <input type="text" name="bloodgroup"  class="form-control" 
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Address</label>
                                                    <input type="text" name="address"  class="form-control" 
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for="">Status</label>
                                                    <select name="status" class="form-control">
                                                        <option value="" selected disabled>-Select-</option>
                                                        <option value="on">On</option>
                                                        <option value="off">Off</option>
                                                    </select>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <br>
                                        <button type="submit" class="btn btn-primary w-25" name="submit">Update</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Loading Scripts -->
        <?php include('../includes/js.php'); ?>

</body>

</html>