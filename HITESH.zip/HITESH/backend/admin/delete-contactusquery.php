<?php
include('../includes/dbconnection.php');
$id = $_GET['id'];
$query = "DELETE FROM contactusquery WHERE id=$id";
$result = $conn->query($query);
header('location:manage-contactus-query.php');
?>