<!doctype html>
<html lang="en" class="no-js">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="theme-color" content="#3e454c">

  <title>BBDMS | Manag Blood Group</title>
  <?php include('../includes/cs.php'); ?>
</head>

<body>
<?php include('../includes/adminheader.php'); ?>

<div class="ts-main-content">
  <?php include('../includes/adminsidebar.php'); ?>
    <div class="content-wrapper">
      <div class="container-fluid">

        <div class="row">
          <div class="col-md-12">

            <h2 class="page-title mt-2">Donor List</h2>

            <!-- Zero Configuration Table -->
            <div class="panel panel-default">
              <div class="panel-heading">Donor List</div>
              <div class="panel-body">
                <table class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Mobile No</th>
                      <th>Email</th>
                      <th>Age</th>
                      <th>Gender</th>
                      <th>Blood Group </th>
                      <th>Address</th>
                      <th>Message</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Mobile No</th>
                      <th>Email</th>
                      <th>Age</th>
                      <th>Gender</th>
                      <th>Blood Group </th>
                      <th>Address</th>
                      <th>Message</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                    </tr>
                  </tfoot>
                  <tbody>
                    <?php
                    $query = "SELECT * FROM blooddonars";
                    $result = $conn->query($query);
                    while ($data = $result->fetch_assoc()) {
                    
                    echo "
                            <tr>
                              <td>
                                $data[id]         
                              </td>
                              <td>
                                $data[name]           
                              </td>
                              <td>
                                $data[contact]            
                              </td>
                              <td>
                                $data[email]            
                              </td>
                              <td>
                                $data[age]            
                              </td>
                              <td>
                                $data[gender]            
                              </td>
                              <td>
                                $data[bloodgroup]            
                              </td>
                              <td>
                                $data[address]            
                              </td>
                              <td>
                                $data[message]           
                              </td>
                              <td>
                                $data[status]            
                              </td>
                              <td>
                                <a href='update-donor.php?id=$data[id]' name='update'><i class='fa fa-edit' aria-hidden='true'></i></a>
                                  ||
                                <a href='delete-donor.php?id=$data[id]' name='delete'><i class='fa fa-trash fa-delete' onclick='return confirmDelete();'></i></a>
                                                
                              </td>
                                           
                            </tr>";
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Loading Scripts -->
  <?php include('../includes/js.php'); ?>

</body>
<script>
  function confirmDelete() {
    return confirm("Are you sure you want to delete the Donor?");
  }
</script>

</html>