<?php
include('../includes/dbconnection.php');
$id = $_GET['id'];
$query = "DELETE FROM blooddonars WHERE id=$id";
$result = $conn->query($query);
header('location:manage-donors-list.php');
?>