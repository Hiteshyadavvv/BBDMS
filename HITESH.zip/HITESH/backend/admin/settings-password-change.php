<?php
include("../includes/adminheader.php");
include("../includes/adminsidebar.php");
?>

<div class="main_content" id="main-content">
    <div class="page">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">Change Password</a>
        </nav>
        <div class="container-fluid">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h2>Change Password</h2>
                    </div>
                    <div class="body">

                        <?php
                        $query_admin = "SELECT * FROM admin";
                        $result_admin = $conn->query($query_admin);
                        $data_admin = $result_admin->fetch_assoc();

                        $error = ""; // Initialize error message variable
                        
                        if (isset($_POST["submit"])) {
                            $currentpassword = $_POST['currentpassword'];
                            $newpassword = $_POST['newpassword'];
                            $confirmpassword = $_POST['confirmpassword'];

                            if ($data_admin && isset($data_admin['password'])) { // Check if data exists
                                if (password_verify($currentpassword, $data_admin['password'])) {
                                    if ($newpassword === $confirmpassword) {
                                        // Passwords match
                                     $changepassword = password_hash($_POST['newpassword'], PASSWORD_BCRYPT);
                                     $query = "UPDATE admin set password='$changepassword'";
                                     $result = $conn->query($query);

                                        $error = "<h6 style='color:green;'>Password successfully updated</h6>";
                                    } else {
                                        $error = "<h6 style='color:red;'>New passwords do not match</h6>";
                                    }
                                } else {
                                    $error = "<h6 style='color:red;'>Wrong current password</h6>";
                                }
                            } 
                            // else {
                            //     $error = "<h6 style='color:red;'>Admin account not found</h6>";
                            // }
                        }
                        ?>

                        <!-- Display the error message -->
                        <?php echo $error; ?>


                        <form action=" " method="POST" enctype="multipart/form-data">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="">Current Password</label>
                                            <input type="password" name="currentpassword" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="">New Password</label>
                                            <input type="password" name="newpassword" id="newpassword"
                                                class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="">Confirm Password</label>
                                            <input type="password" name="confirmpassword" cid="confirmpassword"
                                                class="form-control" required>
                                        </div>
                                    </div>

                                </div>
                                <br>
                                <button type="submit" class="btn btn-primary w-25" name="submit"
                                    onclick="checkpass();">Change
                                    Password</button>

                            </div>
                        </form>

                    </div>

                </div>
            </div>

        </div>
    </div>
</div>