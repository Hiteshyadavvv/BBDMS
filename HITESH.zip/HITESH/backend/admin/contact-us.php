<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Contact Us</title>
    <?php include('../includes/cs.php'); ?>
</head>

<body>
    <?php include('../includes/adminheader.php'); ?>
    <?php
    $query = "SELECT * FROM page WHERE type='contactus'";
    $result = $conn->query($query);
    $data = $result->fetch_assoc();



    if (isset($_POST["submit"])) {
        
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $description = $_POST['description'];

        $query1 = "UPDATE page set  email='$email',contact='$contact' ,description='$description' WHERE type='contactus'";
        $result1 = $conn->query($query1);
        if ($result1) {
            echo "<script>
                alert('updated successfully');
                window.location.href = 'contact-us.php';
            </script>";
            exit();
        }
        

        
    }
    ?>

    <div class="ts-main-content">
        <?php include('../includes/adminsidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title mt-2">Contact Us</h2>

                        <!-- Zero Configuration Table -->
                        <div class="panel panel-default">
                            <div class="panel-heading">Contact Us</div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <form action="" method="post">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for=""><b>Page Title:</b></label>
                                                    <input type="text" name="title" class="form-control"
                                                        value="<?php echo $data['type']; ?>" readonly required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for=""><b>Email</b></label>
                                                    <input type="email" name="email" class="form-control"
                                                        value="<?php echo $data['email']; ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for=""><b>Contact</b></label>
                                                    <input type="text" name="contact" class="form-control"
                                                        value="<?php echo $data['contact']; ?>"
                                                        placeholder="Please enter your phone number" pattern="\d{10,12}"
                                                        title="Phone number must be between 10 and 12 digits"
                                                        maxlength="12" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label for=""><b>Page Description: (Address)</b></label>
                                                    <textarea name="description" id="summernote"
                                                        class="form-control"> <?php echo $data['description']; ?> </textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <button type="submit" class="btn btn-primary w-25" name="submit">Update</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <!-- Loading Scripts -->
        <?php include('../includes/js.php'); ?>

</body>

</html>