<!doctype html>
<html lang="en" class="no-js">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="theme-color" content="#3e454c">

  <title>BBDMS | Manag Blood Group</title>
  <?php include('../includes/cs.php'); ?>
</head>

<body>
  <?php include('../includes/adminheader.php'); ?>

  <div class="ts-main-content">
    <?php include('../includes/adminsidebar.php'); ?>
    <div class="content-wrapper">
      <div class="container-fluid">

        <div class="row">
          <div class="col-md-12">

            <h2 class="page-title mt-2">Manage Blood Groups</h2>

            <!-- Zero Configuration Table -->
            <div class="panel panel-default">
              <div class="panel-heading">Listed Blood Groups</div>
              <div class="panel-body">
                <table class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Blood Groups</th>
                      <th>Creation Date</th>


                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>ID</th>
                      <th>Blood Groups</th>
                      <th>Creation Date</th>
                      <th>Action</th>
                    </tr>
                    </tr>
                  </tfoot>
                  <tbody>
                    <?php
                    $query = "SELECT * FROM bloodgroup";
                    $result = $conn->query($query);
                    while ($data = $result->fetch_assoc()) {

                      echo "
                            <tr>
                              <td>
                                $data[id]         
                              </td>
                              <td>
                                $data[bloodgroup]           
                              </td>
                              <td>
                                $data[date]            
                              </td>
                              <td>
                                <a href='delete-bloodgroup.php?id=$data[id]'><i class='fa fa-close'  onclick='return confirmDelete()'></i></a>         
                              </td>        
                            </tr>";
                    }
                    ?>
                  </tbody>
                  
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Loading Scripts -->
  <?php include('../includes/js.php'); ?>

</body>
<script>
  function confirmDelete() {
    return confirm("Are you sure you want to delete the Donor?");
  }
</script>
</html>