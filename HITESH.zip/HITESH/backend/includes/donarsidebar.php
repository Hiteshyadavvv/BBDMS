<nav class="ts-sidebar" style="margin-top:20px">
	<ul class="ts-sidebar-menu">

		<li class="ts-label">Main</li>
		<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		<li><a href="manage-total-request.php"><i class="fa fa-dashboard"></i> Request list</a></li>

		<!-- <li><a href="#"><i class="fa fa-files-o"></i> Blood Group</a>
			<ul>
				<li><a href="add-bloodgroup.php">Add Blood Group</a></li>
				<li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
			</ul>
		</li>
		<li><a href="#"><i class="fa fa-users"></i> Blood Donor</a>
			<ul>
				<li><a href="add-donor.php">Add Donor</a></li>
				<li><a href="manage-donors-list.php">Manage Donor</a></li>
			</ul>
		</li>
		<li><a href="#"><i class="fa fa-files-o"></i> Manage Pages</a>
			<ul>
				<li><a href="about-us.php">About Us</a></li>
				<li><a href="contact-us.php">Contact Us</a></li>
			</ul>
		</li> -->
		<!-- <li><a href="manage-contactus-query.php"><i class="fa fa-desktop"></i> Manage Conatctus Query</a></li> -->
		<!-- <li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li> -->
		<!-- <li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Update Contact Info</a></li> -->
		<!-- <li><a href="manage-total-request.php"><i class="fa fa-users"></i> Blood Requests</a></li> -->
		<!-- <li><a href="request-received-bydonar.php"><i class="fa fa-search"></i>Search Blood Request</a></li> -->

	</ul>
</nav>