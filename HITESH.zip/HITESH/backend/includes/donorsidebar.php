<?php
include('dbconnection.php');
?>
<div class="left_sidebar">
	<nav class="sidebar" style="background-color: rgba(119, 247, 217, 0.92);">
		<div class="user-info">
			<div class="image"><a href="javascript:void(0);"><img src="../../public/backend/assets/images/ts-avatar.jpg"
						alt="User"></a></div>
			<div class="detail mt-3">
				<?php

				$id = $_SESSION['email'];
				$query = "SELECT * FROM blooddonars WHERE email='$id'";
				$result = $conn->query($query);
				$data = $result->fetch_assoc(); 
				?>
				<h5 class="mb-0"><?php
				echo $data['name'];
				?></h5>
				<small><?php
				// echo $data['Email']; 
				?></small>
			</div>
			<br>
		</div>
		<ul id="main-menu" class="metismenu">

			<li class="active"><a href="dashboard.php"><i class="ti-home"></i><span>Dashboard</span></a></li>
			<!-- <li>
				<a href="" class="has-arrow"><i class="ti-user"></i><span>Driver</span></a>
				<ul>
					<li><a href="../admin/add-driver.php">Add Driver</a></li>
					<li><a href="../admin/manage-driver.php">Manage Driver</a></li>

				</ul>
			</li>
			<li>
				<a href="" class="has-arrow"><i class="ti-pencil-alt"></i><span>Page</span></a>
				<ul>
					<li><a href="aboutus.php">About Us</a></li>
					<li><a href="contactus.php">Contact Us</a></li>

				</ul>
			</li>
			<li>
				<a href="javascript:void(0)" class="has-arrow"><i class="ti-pencil-alt"></i><span>Request</span></a>
				<ul>
					<li><a href="all-request.php">All Request</a></li>
					<li><a href="new-request.php">New Request</a></li>
					<li><a href="approved-request.php">Approved Request</a></li>
					<li><a href="cancel-request.php">Cancel Request</a></li>

				</ul>
			</li>
			<li>
				<a href="javascript:void(0)" class="has-arrow"><i class="ti-view-list"></i><span>Driver
						Response</span></a>
				<ul>
					<li><a href="ontheway.php">On The Way</a></li>
					<li><a href="completed.php">Task Completed</a></li>

				</ul>
			</li>
			<li><a href="search.php"><i class="ti-search"></i><span>Search</span></a></li>

			<li class="open-top">
				<a href="javascript:void(0)" class="has-arrow"><i class="ti-lock"></i><span>Report</span></a>
				<ul>
					<li><a class="dropdown-item" href="between-dates-reports.php">B/w Dates</a></li>
					<li><a class="dropdown-item" href="driverwise-report.php">Driverwise report</a></li>

				</ul>
			</li> -->

		</ul>
	</nav>
</div>