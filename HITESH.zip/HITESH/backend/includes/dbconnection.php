<?php
$server="localhost";
$username="root";
$password= "";
$database= "bbdmsdb";
$conn=mysqli_connect($server,$username,$password,$database);
?>