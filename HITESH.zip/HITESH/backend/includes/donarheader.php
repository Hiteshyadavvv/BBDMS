<?php
session_start();
if (isset($_SESSION['email'])) {

} else {
    header('location:../../donor/login.php');
    exit;

}
?>
<?php 
include('dbconnection.php');
$sql="SELECT * FROM blooddonars WHERE email='".$_SESSION['email']."'";
$result=$conn->query($sql);
$data=$result->fetch_assoc();
?>

<div class="brand clearfix " >
	<a href="dashboard.php" style="font-size: 35px; padding-top:1%; color:#fff;text-align:center;margin-left:30px;margin-top:20px">BloodBank & Donor Management System </a>
	<span class="menu-btn"><i class="fa fa-bars"></i></span>
	<ul class="ts-profile-nav" style="margin-top:10px">

		<li class="ts-account" >
			<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""><?php echo $data['name'] ?> <i
					class="fa fa-angle-down hidden-side"></i></a>
			<ul>
				<li><a href="update-profile.php">Profile</a></li>
				<li><a href="change-password.php">Change Password</a></li>
				<li><a href="logout.php" onclick="return confirmDelete();">Logout</a></li>
				<script>
					function confirmDelete() {
						return confirm("Are you sure you want to logout?");
					}
				</script>
			</ul>
		</li>
	</ul>
</div>