<?php
include('dbconnection.php');
?>

<div class="brand clearfix">
	<a href="dashboard.php"
		style="font-size: 35px; margin-top:10px; color:#fff;text-align:center;margin-left:40px;">BloodBank & Donor
		Management System </a>
	<span class="menu-btn"><i class="fa fa-bars"></i></span>
	<ul class="ts-profile-nav" style="margin-top:10px">

		<li class="ts-account">
			<a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i
					class="fa fa-angle-down hidden-side"></i></a>
			<ul>
				<li><a href="update-profile.php">Profile</a></li>
				<li><a href="change-password.php">Change Password</a></li>
				<li><a href="logout.php" onclick="return confirmDelete();">Logout</a></li>
				<script>
					function confirmDelete() {
						return confirm("Are you sure you want to logout?");
					}
				</script>
			</ul>
		</li>
	</ul>
</div>