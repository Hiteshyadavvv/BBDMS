<!-- Loading Scripts -->
<script src="../public/js/jquery.min.js"></script>
<script src="../public/js/bootstrap-select.min.js"></script>
<script src="../public/js/bootstrap.min.js"></script>
<script src="../public/js/jquery.dataTables.min.js"></script>
<script src="../public/js/dataTables.bootstrap.min.js"></script>
<script src="../public/js/Chart.min.js"></script>
<script src="../public/js/fileinput.js"></script>
<script src="../public/js/chartData.js"></script>
<script src="../public/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/summernote@0.9.0/dist/summernote.min.js"></script>
<script>
  $(document).ready(function () {
    $('#summernote').summernote();
  });
</script>