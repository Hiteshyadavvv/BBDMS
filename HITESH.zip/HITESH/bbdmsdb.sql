-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2025 at 07:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `phone`, `email`, `password`) VALUES
(2, 'Hitesh Yadav', 'admin', 1345678106, 'hiteshyadav2004@gmail.com', '$2y$10$MAIfBU.3/KA4a1eAPdiY1eRjKzDB96a4u/85S3Pq9DJjRlqLMFcGW');

-- --------------------------------------------------------

--
-- Table structure for table `blooddonars`
--

CREATE TABLE `blooddonars` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `gender` enum('male','female','other','') NOT NULL,
  `age` int(11) NOT NULL,
  `bloodgroup` text NOT NULL,
  `address` text NOT NULL,
  `message` text NOT NULL DEFAULT 'NA',
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('on','of') NOT NULL DEFAULT 'on',
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blooddonars`
--

INSERT INTO `blooddonars` (`id`, `name`, `contact`, `email`, `gender`, `age`, `bloodgroup`, `address`, `message`, `date`, `status`, `password`) VALUES
(3, 'GANESH KUNWAR', 9372970769, 'kunwarganesh2003@gmail.com', 'male', 22, 'O+', 'azad maidan', 'kjhgfd', '2025-04-17 04:58:44', 'on', '$2y$10$zeXQmuZb11cb2j/Nx83HTusInz7M9ZW0Z/somL.0FSdvmIsSFVA5.'),
(21, 'HITESH YADAAV', 2345678221, 'hitesh1@gmail.com', 'male', 19, 'O-', 'Mumbai Goregaon', 'hello', '2025-04-17 04:58:44', 'on', '$2y$10$zeXQmuZb11cb2j/Nx83HTusInz7M9ZW0Z/somL.0FSdvmIsSFVA5.'),
(22, 'Riya', 1234567890, 'riya1@gmail.com', 'female', 19, 'AB+', 'Mumbai ', 'hello', '2025-04-17 04:58:44', 'on', '$2y$10$zeXQmuZb11cb2j/Nx83HTusInz7M9ZW0Z/somL.0FSdvmIsSFVA5.'),
(23, 'Roshan yadav', 12345678905, 'roshan@gmail.com', 'male', 20, 'A+', 'mumbai', 'message me', '2025-04-17 05:24:39', 'on', '$2y$10$zeXQmuZb11cb2j/Nx83HTusInz7M9ZW0Z/somL.0FSdvmIsSFVA5.'),
(24, 'Sumit yadav', 21474836475, 'sumit@gmail.com', 'male', 22, 'B+', 'Mumbai ', 'hello', '2025-04-17 04:58:44', 'on', '$2y$10$zeXQmuZb11cb2j/Nx83HTusInz7M9ZW0Z/somL.0FSdvmIsSFVA5.');

-- --------------------------------------------------------

--
-- Table structure for table `bloodgroup`
--

CREATE TABLE `bloodgroup` (
  `id` int(11) NOT NULL,
  `bloodgroup` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bloodgroup`
--

INSERT INTO `bloodgroup` (`id`, `bloodgroup`, `date`) VALUES
(1, 'A+', '2025-02-23 08:10:48');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequest`
--

CREATE TABLE `bloodrequest` (
  `id` int(11) NOT NULL,
  `donarname` varchar(255) NOT NULL,
  `donarcontact` bigint(20) NOT NULL,
  `bloodgroup` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `bloodfor` enum('father','mother','brother','sister','other') NOT NULL,
  `message` text NOT NULL,
  `applydate` timestamp NOT NULL DEFAULT current_timestamp(),
  `request_to` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bloodrequest`
--

INSERT INTO `bloodrequest` (`id`, `donarname`, `donarcontact`, `bloodgroup`, `name`, `contact`, `email`, `bloodfor`, `message`, `applydate`, `request_to`) VALUES
(1, 'GANESH KUNWAR', 9372970769, 'O+', 'Abhishek', 1234567890, 'qamah@mailinator.com', 'father', 'jsda', '2025-02-23 10:39:15', ''),
(2, 'Amit', 12345678905, 'O+', 'Chandan', 1234567890, 'driver123@gmail.com', 'brother', 'fgfgfsg', '2025-02-23 10:39:15', ''),
(3, 'Kennan Ferguson', 814565642342, 'O+', 'GANESH KUNWAR', 12345678905, 'driver123@gmail.com', '', 'dsfssg', '2025-02-23 10:39:15', ''),
(4, 'GANESH KUNWAR', 9372970769, 'O+', 'DRIVER', 21474836475, 'ghagha@email.com', 'father', 'gregerg', '2025-02-24 04:05:10', ''),
(5, 'GANESH KUNWAR', 9372970769, 'O+', 'HITESH YADAAV', 12345678905, 'hitesh@gmail.com', 'mother', 'hhhh', '2025-03-06 05:58:31', ''),
(6, 'HITESH YADAAV', 2345678221, 'O-', 'hitesh', 1234567890, 'roshan@gmail.com', 'father', 'blood', '2025-04-17 05:11:41', '');

-- --------------------------------------------------------

--
-- Table structure for table `contactusquery`
--

CREATE TABLE `contactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `phone` bigint(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactusquery`
--

INSERT INTO `contactusquery` (`id`, `name`, `email`, `phone`, `date`, `message`) VALUES
(1, 'test', 'test@gmail.com', 1234567890, '2025-02-22 21:49:48', 'i want blood'),
(2, 'hitesh', 'hitesh@gmail.com', 720818195, '2025-04-17 05:08:32', 'i Want blood');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `email` text NOT NULL,
  `contact` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `type`, `description`, `email`, `contact`) VALUES
(1, 'aboutus', '   Welcome to the Blood Bank Donor Management System! Our project is designed to make the blood donation process easier and more efficient. It connects donors, blood recipients, and hospitals, ensuring that life-saving blood is always available when needed. The system allows donors to sign up, schedule their donations, and track their donation history. It also helps blood banks keep track of their blood supply and manage donor details effectively. Our main goal is to make donating blood simple, organized, and transparent, helping save lives and improve healthcare. We focus on security, ease of use, and accuracy to ensure the system is helpful for both donors and medical facilities. Our aim is to create a world where everyone can get the blood they need in an emergency, with the support of a strong and caring community.   ', 'xyz@gmail.com', 1234567890),
(2, 'contactus', '         Ram Mandir ', 'xyz@gmail.com', 1234567890);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blooddonars`
--
ALTER TABLE `blooddonars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodgroup`
--
ALTER TABLE `bloodgroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactusquery`
--
ALTER TABLE `contactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `blooddonars`
--
ALTER TABLE `blooddonars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `bloodgroup`
--
ALTER TABLE `bloodgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contactusquery`
--
ALTER TABLE `contactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
