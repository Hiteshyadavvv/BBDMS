<?php
include("includes/header.php");
?>


<?php
if (isset($_POST['send'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $sql = "INSERT INTO  contactusquery(name,email,phone,message) VALUES('$name','$email','$phone','$message')";
    $query = $conn->query($sql);
    if($query){
        echo "<script>alert('Your message has been sent successfully');</script>";
    }
    // $sql = "SELECT * from contactus";
// $query = $conn->query($sql);
// $data = $query->fetch_assoc();

    // $lastInsertId = $conn->lastInsertId();
// if($lastInsertId)
// {

    // echo '<script>alert("Query Sent. We will contact you shortly.")</script>';
// }
// else 
// {
// echo "<script>alert('Something went wrong. Please try again.');</script>";  
// }

}
?>


<!-- banner 2 -->
<div class="inner-banner-w3ls">
    <div class="container">

    </div>
    <!-- //banner 2 -->
</div>
<!-- page details -->
<div class="breadcrumb-agile">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
        </ol>
    </div>
</div>
<!-- //page details -->

<!-- contact -->
<div class="agileits-contact py-5">
    <div class="py-xl-5 py-lg-3">
        <div class="w3ls-titles text-center mb-5">
            <h3 class="title">Contact Us</h3>
            <span>
                <i class="fas fa-user-md"></i>
            </span>
            <!-- <p class="mt-2">Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p> -->
        </div>
        <div class="d-flex">
            <div class="col-lg-5 ">
                <div class="w3_agileits-contact-left-grid">
                    <img src="images/touch.jpg" height="800px" width="600px" alt=""
                        style="float: left; margin-right: 10px;">
                </div>

            </div>
            <div class="col-lg-7 contact-right-w3l">
                <h5 class="title-w3 text-center mb-5">Get In Touch</h5>
                <form action=" " method="post">
                    <div class="d-flex space-d-flex">
                        <div class="form-group grid-inputs">
                            <input type="text" class="form-control" id="name" name="name" required
                                placeholder="Please enter your name.">
                        </div>
                        <div class="form-group grid-inputs">
                            <input type="text" class="form-control" id="phone" name="phone" required
                                placeholder="Please enter your phone number" pattern="\d{10,12}"
                                title="Phone number must be between 10 and 12 digits" maxlength="12">
                        </div>


                        <!-- <div class="form-group grid-inputs">
                            <input type="tel" class="form-control" id="phone" name="phone" required
                                placeholder="Please enter your phone number.">
                        </div> -->
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" id="email" name="email" required
                            placeholder="Please enter your email address.">
                    </div>


                    <div class="form-group">
                        <textarea rows="10" cols="100" class="form-control" id="message" name="message"
                            placeholder="Please enter your message" maxlength="999" style="resize:none"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Send Message" name="send" >
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include("includes/footer.php");
?>